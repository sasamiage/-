package com.example.autobackup;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.mojang.brigadier.arguments.IntegerArgumentType;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * ワールドを自動でzipにバックアップするMod。
 *  - 一定時間(初期30分)ごとに自動バックアップ
 *  - /backup now で今すぐバックアップ
 *  - 古いバックアップは、指定した個数(初期10個)だけ残して自動で削除
 *  - 保存先: <ゲームフォルダ>/backups/<ワールド名>/<ワールド名>_日時.zip
 *  - zipの中には「ワールド名のフォルダ」ごと入っているので、ランチャーのセーブのインポートでそのまま戻せる
 * ワールド（サーバー）側で動くので、1人用ならこのModを入れるだけでOK。
 */
@Mod(AutoBackup.MOD_ID)
public class AutoBackup {
    public static final String MOD_ID = "autobackup";

    // ---- 設定（コマンドで変更、ファイルに保存される）----
    private static volatile boolean enabled = true;
    private static volatile int intervalMinutes = 30;
    private static volatile int keepCount = 10;
    private static volatile boolean backupOnStart = false;

    private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "AutoBackup");
        t.setDaemon(true);
        return t;
    });

    private static volatile boolean running = false;
    private static volatile boolean cancel = false;
    private static long tickCounter = 0;

    public AutoBackup(IEventBus modEventBus) {
        load();
        NeoForge.EVENT_BUS.addListener(AutoBackup::onServerStarted);
        NeoForge.EVENT_BUS.addListener(AutoBackup::onServerStopping);
        NeoForge.EVENT_BUS.addListener(AutoBackup::onServerTick);
        NeoForge.EVENT_BUS.addListener(AutoBackup::onRegisterCommands);
    }

    // ---------------- タイマー ----------------
    private static void onServerStarted(ServerStartedEvent event) {
        tickCounter = 0;
        cancel = false;
        if (enabled && backupOnStart) {
            startBackup(event.getServer());
        }
    }

    private static void onServerTick(ServerTickEvent.Post event) {
        if (!enabled || running) return;
        MinecraftServer server = event.getServer();
        if (server.getPlayerList().getPlayerCount() == 0) return; // 誰もいないときは数えない
        if (++tickCounter >= intervalMinutes * 20L * 60L) {
            startBackup(server);
        }
    }

    /** ワールドを閉じるとき、バックアップ中ならやめて、保存を元に戻す（最後の保存が飛ばないように） */
    private static void onServerStopping(ServerStoppingEvent event) {
        cancel = true;
        for (ServerLevel level : event.getServer().getAllLevels()) {
            level.noSave = false;
        }
    }

    // ---------------- バックアップ本体 ----------------
    private static Path worldDir(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize();
    }

    private static Path backupDir(String worldName) {
        return FMLPaths.GAMEDIR.get().resolve("backups").resolve(worldName);
    }

    /** バックアップを始める。すでに実行中なら false */
    private static synchronized boolean startBackup(MinecraftServer server) {
        if (running) return false;
        running = true;
        cancel = false;
        tickCounter = 0;
        actionbar(server, "バックアップ中…");

        // いったん今の状態を全部ディスクに書き出して、コピー中は自動保存を止める
        server.saveEverything(true, true, true);
        List<ServerLevel> levels = new ArrayList<>();
        for (ServerLevel level : server.getAllLevels()) {
            level.noSave = true;
            levels.add(level);
        }

        Path worldDir = worldDir(server);
        String worldName = worldDir.getFileName().toString();
        Path dir = backupDir(worldName);
        Path zip = dir.resolve(worldName + "_" + LocalDateTime.now().format(STAMP) + ".zip");

        EXECUTOR.submit(() -> {
            long size = 0;
            String error = null;
            try {
                size = zipWorld(worldDir, zip);
                prune(dir, worldName, keepCount);
            } catch (Throwable t) {
                error = String.valueOf(t.getMessage());
                try {
                    Files.deleteIfExists(zip.resolveSibling(zip.getFileName() + ".tmp"));
                } catch (IOException ignored) {
                    // 無視
                }
            }
            final long fsize = size;
            final String ferror = error;
            server.execute(() -> {
                for (ServerLevel level : levels) {
                    level.noSave = false;
                }
                running = false;
                if (ferror == null) {
                    actionbar(server, "バックアップ完了（" + mb(fsize) + "）");
                } else if (!cancel) {
                    chatAll(server, "バックアップに失敗した: " + ferror);
                }
            });
        });
        return true;
    }

    /** ワールドフォルダをzipにする。zipの中は「ワールド名/…」の形 */
    private static long zipWorld(Path worldDir, Path zipFile) throws IOException {
        Files.createDirectories(zipFile.getParent());
        Path tmp = zipFile.resolveSibling(zipFile.getFileName() + ".tmp");
        String root = worldDir.getFileName().toString();

        List<Path> paths;
        try (Stream<Path> walk = Files.walk(worldDir)) {
            paths = walk.toList();
        }

        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(tmp))) {
            zos.setLevel(Deflater.BEST_SPEED); // 速さ優先（ワールドの中身は元から圧縮されている）
            for (Path p : paths) {
                if (cancel) throw new IOException("中止した");
                String rel = worldDir.relativize(p).toString().replace('\\', '/');
                if (Files.isDirectory(p)) {
                    if (!rel.isEmpty()) {
                        zos.putNextEntry(new ZipEntry(root + "/" + rel + "/"));
                        zos.closeEntry();
                    }
                    continue;
                }
                if (p.getFileName().toString().equals("session.lock")) continue;
                try (InputStream in = Files.newInputStream(p)) {
                    zos.putNextEntry(new ZipEntry(root + "/" + rel));
                    in.transferTo(zos);
                    zos.closeEntry();
                } catch (NoSuchFileException ignored) {
                    // コピー中に消えたファイルは飛ばす
                }
            }
        }
        Files.move(tmp, zipFile, StandardCopyOption.REPLACE_EXISTING);
        return Files.size(zipFile);
    }

    /** 古いバックアップを消して、新しい方から keep 個だけ残す */
    private static void prune(Path dir, String worldName, int keep) throws IOException {
        List<Path> zips = listBackups(dir, worldName);
        for (int i = 0; i < zips.size() - keep; i++) {
            Files.deleteIfExists(zips.get(i));
        }
    }

    /** バックアップ一覧（古い順） */
    private static List<Path> listBackups(Path dir, String worldName) throws IOException {
        if (!Files.isDirectory(dir)) return List.of();
        try (Stream<Path> s = Files.list(dir)) {
            return s.filter(p -> {
                String n = p.getFileName().toString();
                return n.startsWith(worldName + "_") && n.endsWith(".zip");
            }).sorted().toList();
        }
    }

    private static String mb(long bytes) {
        return String.format("%.1f MB", bytes / 1024.0 / 1024.0);
    }

    // ---------------- メッセージ ----------------
    private static void actionbar(MinecraftServer server, String text) {
        Component c = Component.literal(text);
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.sendSystemMessage(c, true);
        }
    }

    private static void chatAll(MinecraftServer server, String text) {
        server.getPlayerList().broadcastSystemMessage(Component.literal(text), false);
    }

    // ---------------- コマンド ----------------
    private static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("backup")
                        // 1人用ならOP権限なしで使える。マルチならOPだけ
                        .requires(src -> src.hasPermission(2) || src.getServer().isSingleplayer())
                        .then(Commands.literal("now").executes(c -> now(c.getSource())))
                        .then(Commands.literal("on").executes(c -> setEnabled(c.getSource(), true)))
                        .then(Commands.literal("off").executes(c -> setEnabled(c.getSource(), false)))
                        .then(Commands.literal("interval")
                                .then(Commands.argument("minutes", IntegerArgumentType.integer(1, 1440))
                                        .executes(c -> setInterval(c.getSource(),
                                                IntegerArgumentType.getInteger(c, "minutes")))))
                        .then(Commands.literal("keep")
                                .then(Commands.argument("count", IntegerArgumentType.integer(1, 100))
                                        .executes(c -> setKeep(c.getSource(),
                                                IntegerArgumentType.getInteger(c, "count")))))
                        .then(Commands.literal("start")
                                .then(Commands.literal("on").executes(c -> setStart(c.getSource(), true)))
                                .then(Commands.literal("off").executes(c -> setStart(c.getSource(), false))))
                        .then(Commands.literal("list").executes(c -> list(c.getSource())))
                        .executes(c -> status(c.getSource())));
    }

    private static void reply(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    private static int now(CommandSourceStack src) {
        if (startBackup(src.getServer())) {
            reply(src, "バックアップを始めた");
            return 1;
        }
        reply(src, "すでにバックアップ中");
        return 0;
    }

    private static int setEnabled(CommandSourceStack src, boolean value) {
        enabled = value;
        tickCounter = 0;
        save();
        reply(src, "自動バックアップ: " + (value ? "ON（" + intervalMinutes + "分ごと）" : "OFF"));
        return 1;
    }

    private static int setInterval(CommandSourceStack src, int minutes) {
        intervalMinutes = minutes;
        tickCounter = 0;
        save();
        reply(src, "バックアップの間隔を " + minutes + " 分にした");
        return 1;
    }

    private static int setKeep(CommandSourceStack src, int count) {
        keepCount = count;
        save();
        reply(src, "バックアップを新しい方から " + count + " 個だけ残すことにした（古いものは次のバックアップ時に消える）");
        return 1;
    }

    private static int setStart(CommandSourceStack src, boolean value) {
        backupOnStart = value;
        save();
        reply(src, "ワールドを開いたときのバックアップ: " + (value ? "ON" : "OFF"));
        return 1;
    }

    private static int status(CommandSourceStack src) {
        Path dir = backupDir(worldDir(src.getServer()).getFileName().toString());
        int count = 0;
        try {
            count = listBackups(dir, worldDir(src.getServer()).getFileName().toString()).size();
        } catch (IOException ignored) {
            // 無視
        }
        reply(src, "自動バックアップ: " + (enabled ? "ON" : "OFF")
                + " / " + intervalMinutes + "分ごと / " + keepCount + "個まで残す"
                + " / 開いたとき: " + (backupOnStart ? "ON" : "OFF"));
        reply(src, "今あるバックアップ: " + count + "個");
        reply(src, "保存先: " + dir);
        return 1;
    }

    private static int list(CommandSourceStack src) {
        String name = worldDir(src.getServer()).getFileName().toString();
        Path dir = backupDir(name);
        try {
            List<Path> zips = listBackups(dir, name);
            if (zips.isEmpty()) {
                reply(src, "バックアップはまだない");
                return 1;
            }
            reply(src, "バックアップ一覧（新しい順）");
            int shown = 0;
            for (int i = zips.size() - 1; i >= 0 && shown < 10; i--, shown++) {
                Path p = zips.get(i);
                reply(src, " - " + p.getFileName() + "（" + mb(Files.size(p)) + "）");
            }
        } catch (IOException e) {
            reply(src, "一覧を読めなかった: " + e.getMessage());
        }
        return 1;
    }

    // ---------------- 設定の保存・読み込み ----------------
    private static Path configPath() {
        return FMLPaths.CONFIGDIR.get().resolve("autobackup.txt");
    }

    private static void save() {
        try {
            List<String> lines = List.of(
                    "enabled=" + enabled,
                    "interval=" + intervalMinutes,
                    "keep=" + keepCount,
                    "start=" + backupOnStart);
            Files.write(configPath(), lines, StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException ignored) {
            // 保存に失敗してもゲームは続ける
        }
    }

    private static void load() {
        try {
            Path path = configPath();
            if (!Files.exists(path)) return;
            for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                int eq = line.indexOf('=');
                if (eq < 0) continue;
                String key = line.substring(0, eq).trim();
                String value = line.substring(eq + 1).trim();
                switch (key) {
                    case "enabled" -> enabled = Boolean.parseBoolean(value);
                    case "interval" -> intervalMinutes = Math.max(1, Math.min(1440, Integer.parseInt(value)));
                    case "keep" -> keepCount = Math.max(1, Math.min(100, Integer.parseInt(value)));
                    case "start" -> backupOnStart = Boolean.parseBoolean(value);
                    default -> { }
                }
            }
        } catch (IOException | RuntimeException ignored) {
            // 読み込みに失敗したら初期設定のまま
        }
    }
}
